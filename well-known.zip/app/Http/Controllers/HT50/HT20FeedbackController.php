<?php

namespace App\Http\Controllers\HT50;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HT20FeedbackController extends Controller
{
    //
}
