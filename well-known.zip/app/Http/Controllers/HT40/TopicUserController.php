<?php

namespace App\Http\Controllers\HT40;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TopicUserController extends Controller
{
    //
}
