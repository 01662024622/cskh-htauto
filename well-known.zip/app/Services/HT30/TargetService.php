<?php

namespace App\Services\HT30;

use App\Services\ServiceInterface;

interface TargetService extends ServiceInterface
{
    //
}