<?php

namespace App\Models\HT40;

use Illuminate\Database\Eloquent\Model;

class Topic extends Model
{
    //
}
