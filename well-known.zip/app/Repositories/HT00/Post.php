<?php

namespace App\Repositories\HT00;

use App\Repositories\RepositoryInterface;

interface Post extends RepositoryInterface
{
    //
}