<?php

namespace App\Repositories\HT30;

use App\Repositories\RepositoryInterface;

interface ResultRepository extends RepositoryInterface
{
    //
}