<?php


namespace App\Repositories\HT20;


use App\Repositories\RepositoryInterface;

interface UserRepository extends RepositoryInterface
{

}
