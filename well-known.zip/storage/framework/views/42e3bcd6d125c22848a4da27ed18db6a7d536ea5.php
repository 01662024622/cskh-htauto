
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/review360/feedbackme.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <br><br>
    <table class="table table-bordered" id="users-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Loại phản hồi</th>
            <th>Phòng Ban</th>
            <th>Feedback</th>
            <th>Tên HĐ</th>
            <th>Nội dung</th>
            <th>Ảnh</th>
            <th>Ngày tạo</th>
            <th>Phản hồi</th>
            <th>Hành Động</th>
        </tr>
        </thead>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/review360/feedbackBrowser.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/report_review/feedbackBrowser.blade.php ENDPATH**/ ?>