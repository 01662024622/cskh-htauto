<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/categories/list.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h3><?php echo e($post->title); ?></h3>
<span class="date"><?php echo e($post->created_at); ?></span>
<br>
<br>
<?php if($post->embed!=''): ?>
<button class="btn btn-info" onclick="openFullscreen()">Mở rộng</button>
<?php endif; ?>
<br>
<br>

<div class="row">
    <div class="col-12"><?php echo $post->content; ?></div>
    <div id="full-screen" class="col-12">
        <?php echo $post->embed; ?>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
        $( "div#full-screen :first-child" ).css({'width':'100%','height':'100vh'})
        function openFullscreen(){
            var embed = $( "div#full-screen :first-child" )[0];
            var rFS = embed.mozRequestFullScreen || embed.webkitRequestFullscreen || embed.requestFullscreen;
            rFS.call(embed);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/posts/show.blade.php ENDPATH**/ ?>