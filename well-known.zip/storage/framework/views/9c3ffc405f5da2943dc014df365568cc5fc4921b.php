
<?php $__env->startSection('css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.min.css" rel="stylesheet"/>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<br><br>
<button type="button" class="btn btn-primary" data-toggle="modal" href='#add-modal' onclick="clearForm()">Thêm mới</button>

<br><br>
<table class="table table-bordered" id="users-table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Tên Người Dùng</th>
      <th>Email Đăng Nhập</th>
      <th>Số Điện Thoại</th>
      <th>Quyền Hạn</th>
      <th>Hành Động</th>
    </tr>
  </thead>
</table>


<!-- The Modal -->
<div class="modal" id="add-modal">
  <div class="modal-dialog" style="max-width: 700px;">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Thông Tin Người Dùng</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <form id="add-form" action="<?php echo e(asset('/users')); ?>" method="POST" >
        <!-- Modal body -->
        <div class="modal-body">
          <div class="form-group">
            <label for="name">Tên Người Dùng*</label>
            <input type="text" class="form-control" id="name" name="name"  placeholder="Nhập Họ và Tên...">
          </div>
          <div class="form-group">
            <label for="name">Chức Vụ</label>
            <input type="text" class="form-control" id="position" name="position"  placeholder="Nhập Chức Vụ Người Dùng...">
          </div>
          <div class="form-group">
            <label for="exampleFormControlSelect1">Phòng Ban</label>
            <select class="form-control" id="apartment_id" name="apartment_id">
              <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($apartment->id); ?>"><?php echo e($apartment->code); ?>-<?php echo e($apartment->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label for="name">Địa Điểm</label>
            <select class="form-control" id="location" name="location">
              <option value="Hà Nội">Hà Nội</option>
              <option value="TP Hồ Chí Minh">TP Hồ Chí Minh</option>





























































            </select>
          </div>
          <div class="form-group">
            <label for="name">Skype</label>
            <input type="text" class="form-control" id="skype" name="skype"  placeholder="Nhập Skype Người Dùng...">
          </div>
          <div class="form-group">
            <label for="name">Email HTAuto</label>
            <input type="email" class="form-control" id="email_htauto" name="email_htauto"  placeholder="Nhập Email HTAuto...">
          </div>
          <div class="form-group">
            <label for="name">SĐT</label>
            <input type="tel" class="form-control" id="phone" name="phone"  placeholder="Nhập Số Điện Thoại Cá Nhân...">
          </div>
          <div class="form-group">
            <label for="exampleFormControlSelect1">Ngày sinh</label>
            <input class="form-control" data-date-format="dd/mm/yyyy" id="birth_day" name="birth_day">
          </div>
          <input type="hidden" name="id" id="eid">

        </div>

        <!-- Modal footer -->
        <div class="modal-footer">

          <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
          <button type="submit" class="btn btn-primary">Lưu</button>
        </div>
      </form>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<script src="<?php echo e(asset('js/user/users.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/users/index.blade.php ENDPATH**/ ?>