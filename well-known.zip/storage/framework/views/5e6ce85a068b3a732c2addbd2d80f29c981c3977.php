<?php $__env->startSection('css'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.min.css"
          rel="stylesheet"/>
    <link rel="stylesheet" href="https://rawgit.com/adrotec/knockout-file-bindings/master/knockout-file-bindings.css">
    <link rel="stylesheet" href="/public/css/okrs/key.css">
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/css/rowGroup.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-customer page-list">
        <div class="content-header header-height">
            <h1 class="ng-binding">Bảng OKRs</h1>
            <div class="breadcrumb">
                <div style="width: 430px;" class="btn-group search-date divFilterDate">
                    <div class="input-group" id="reportrange">
                        <div class="input-group-addon addon-right"><i class="fa fa-user"></i></div>
                        <input type="text" class="form-control" name="date" id="date">
                        <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                    </div>
                </div>

                <!-- ngIf: activeTab == '' -->
            </div>
        </div>
    </div>


    <br><br>
    <form action="/okrs" method="post" id="edit_ob">
        <table class="table table-bordered" id="users-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Tiêu đề</th>
                <th>Hệ số KRs</th>
                <th>Thực đạt</th>
                <th>Hành Động</th>
            </tr>
            </thead>
        </table>
    </form>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


    <script src="<?php echo e(asset('js/okrs/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/dataTables.rowGroup.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/view_infor/dashboard.blade.php ENDPATH**/ ?>