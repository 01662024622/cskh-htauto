<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <br><br>
    <button type="button" class="btn btn-primary" onclick="clearForm()" data-toggle="modal" href='#add-modal'>+Thêm mới</button>

    <br><br>
    <table class="table table-bordered" id="users-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Tên nhóm</th>
            <th>Người dùng</th>
            <th>Chú Thích</th>
            <th>Hành Động</th>
        </tr>
        </thead>
    </table>


    <!-- The Modal -->
    <div class="modal" id="add-modal">
        <div class="modal-dialog" style="max-width: 700px;">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Thêm mới</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form id="add-form" action="<?php echo e(asset('/groups')); ?>" method="POST" >
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Tên Nhóm*</label>
                            <input type="text" class="form-control" id="name" name="name"  placeholder="Nhập tên nhóm...">
                        </div>
                        <div class="form-group">
                            <label for="name">Note</label>
                            <input type="text" class="form-control" id="description" name="description"  placeholder="Chú thích...">
                        </div>
                        <div id="staff" class="container"><br>
                            <div class="row">
                                <div class="col col-6">
                                    <input type="text" name="apartment_find" id="staff_find_text"
                                           style="width: 150px;" maxlength="30">
                                    <button id="staff_find" type="button">Tìm kiếm</button>
                                    <br>
                                    <p>Kết quả tìm kiếm:</p>
                                    <br>
                                    <select multiple="multiple" id="multiple_staff_select"
                                            style="height:160px; width: 210px;">

                                    </select>
                                    <button id="staff_select" type="button">Chọn</button>
                                </div>
                                <div class="col col-6">
                                    <table style="width:100%" id="staff_role_table">
                                        <tr>
                                            <th>Nhân viên</th>
                                            <th>Quyền hạn</th>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="id" id="eid">
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Lưu</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                    </div>
                </form>
            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/group/index.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/groups/index.blade.php ENDPATH**/ ?>