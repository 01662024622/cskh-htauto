<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/categories/list.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-1"></div>
        <div class="col-10 container-custome">
            <div class="row">
            <div class="col-1 avata-container">
                <img class="image-avata" src="<?php echo e($post->avata); ?>">
            </div>
            <div class="col-10">
                <div class="row">
                    <div class="col-12"><a class="title-link" href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></div>
                    <div class="col-12"><span class="date"><?php echo e($post->updated_at->diffForHumans()); ?></span></div>
                </div>
            </div>
            </div>
            </div>

    </div>
        <br>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/category/edit.blade.php ENDPATH**/ ?>