<?php

namespace App\Models\HT40;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    //
}
