<?php


namespace App\Services\HT00;

use App\Services\ServiceInterface;

interface CategoryService extends ServiceInterface
{

}
