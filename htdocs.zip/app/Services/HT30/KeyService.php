<?php

namespace App\Services\HT30;

use App\Services\ServiceInterface;

interface KeyService extends ServiceInterface
{
    //
}