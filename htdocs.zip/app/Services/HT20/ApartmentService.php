<?php
namespace App\Services\HT20;

use App\Services\ServiceInterface;

interface ApartmentService extends ServiceInterface{

}

