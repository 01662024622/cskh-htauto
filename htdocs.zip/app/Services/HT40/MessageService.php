<?php

namespace App\Services\HT40;

use App\Services\ServiceInterface;

interface MessageService extends ServiceInterface
{
    //
}