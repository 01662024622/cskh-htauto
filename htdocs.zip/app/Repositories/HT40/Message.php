<?php

namespace App\Repositories\HT40;

use App\Repositories\RepositoryInterface;

interface Message extends RepositoryInterface
{
    //
}