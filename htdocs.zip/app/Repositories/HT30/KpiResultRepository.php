<?php

namespace App\Repositories\HT30;

use App\Repositories\RepositoryInterface;

interface KpiResultRepository extends RepositoryInterface
{
    //
}